import requests
# Api : https://api.countrylayer.com/v2/name/{name} by name
# Api : https://restcountries.com/v3.1/currency/{currency} by currency
# Api : https://restcountries.com/v3.1/lang/{language} by language
# Api : https://restcountries.com/v3.1/capital/{capital} by capital
# website : https://restcountries.com/#endpoints-latest-added-enpoint

# --- Function to find by name --- #
def countryInfo_byName(name):
  site = f"https://restcountries.com/v3.1/name/{name}"
  req = requests.get(site)
  res = req.json()
  data = {
    'name':res[0]['name']['common'],
    'currency':res[0]['currencies'],
    'population':res[0]['population'],
    'continents':res[0]['continents'],
    'language':res[0]['languages'],
    'area':res[0]['area'],
    'region':res[0]['region'],
    'subregion':res[0]['subregion'],
    'timezones':res[0]['timezones'],
    'latlng':res[0]['latlng'],
    'borders':res[0]['borders'],
    'altSpellings':res[0]['altSpellings'],
    'startOfWeek':res[0]['startOfWeek']
  }
  # --- Prints the data --- ###
  print(f"\nCOUNTRY INFO \n\nCountry Name: {data['name']}\nRegion: {data['region']}\nSubregion: {data['subregion']}\n")
  print(f"latitude and longitude: {data['latlng']} \nArea: {data['area']}\nPopulation: {data['population']}\n")
  print(f"Currency: {data['currency']} \nTime Zone: {data['timezones']} \nLanguage: {data['language']}\n")
  print(f"Bordering Countries: {data['borders']} \nAlterntive spelling: {data['altSpellings']} \nStart of the week: {data['startOfWeek']} \n")


# --- Function to find by currency --- #
def countryInfo_byCurrency(money):
  site = f"https://restcountries.com/v3.1/currency/{money}"
  req = requests.get(site)
  res = req.json()
  data = {
    'name':res[0]['name']['common'],
    'currency':res[0]['currencies'],
    'population':res[0]['population'],
    'continents':res[0]['continents'],
    'language':res[0]['languages'],
    'area':res[0]['area'],
    'region':res[0]['region'],
    'subregion':res[0]['subregion'],
    'timezones':res[0]['timezones'],
    'latlng':res[0]['latlng'],
    'borders':res[0]['borders'],
    'altSpellings':res[0]['altSpellings'],
    'startOfWeek':res[0]['startOfWeek']
  }
  # --- Prints the data --- ###
  print(f"\nCOUNTRY INFO \n\nCountry Name: {data['name']}\nRegion: {data['region']}\nSubregion: {data['subregion']}\n")
  print(f"latitude and longitude: {data['latlng']} \nArea: {data['area']}\nPopulation: {data['population']}\n")
  print(f"Currency: {data['currency']} \nTime Zone: {data['timezones']} \nLanguage: {data['language']}\n")
  print(f"Bordering Countries: {data['borders']} \nAlterntive spelling: {data['altSpellings']} \nStart of the week: {data['startOfWeek']} \n")


# --- Function to find by capital --- #
def countryInfo_byCapital(capital):
  site = f"https://restcountries.com/v3.1/capital/{capital}"
  req = requests.get(site)
  res = req.json()
  data = {
    'name':res[0]['name']['common'],
    'currency':res[0]['currencies'],
    'population':res[0]['population'],
    'continents':res[0]['continents'],
    'language':res[0]['languages'],
    'area':res[0]['area'],
    'region':res[0]['region'],
    'subregion':res[0]['subregion'],
    'timezones':res[0]['timezones'],
    'latlng':res[0]['latlng'],
    'borders':res[0]['borders'],
    'altSpellings':res[0]['altSpellings'],
    'startOfWeek':res[0]['startOfWeek']
  }  
  # --- Prints the data --- ###
  print(f"\nCOUNTRY INFO \n\nCountry Name: {data['name']}\nRegion: {data['region']}\nSubregion: {data['subregion']}\n")
  print(f"latitude and longitude: {data['latlng']} \nArea: {data['area']}\nPopulation: {data['population']}\n")
  print(f"Currency: {data['currency']} \nTime Zone: {data['timezones']} \nLanguage: {data['language']}\n")
  print(f"Bordering Countries: {data['borders']} \nAlterntive spelling: {data['altSpellings']} \nStart of the week: {data['startOfWeek']} \n")


# --- Function to find by language --- #
def countryInfo_byLanguage(language):
  site = f"https://restcountries.com/v3.1/lang/{language}"
  req = requests.get(site)
  res = req.json()
  data = {
    'name':res[0]['name']['common'],
    'currency':res[0]['currencies'],
    'population':res[0]['population'],
    'continents':res[0]['continents'],
    'language':res[0]['languages'],
    'area':res[0]['area'],
    'region':res[0]['region'],
    'subregion':res[0]['subregion'],
    'timezones':res[0]['timezones'],
    'latlng':res[0]['latlng'],
    'borders':res[0]['borders'],
    'altSpellings':res[0]['altSpellings'],
    'startOfWeek':res[0]['startOfWeek']
  }
  # --- Prints the data --- ###  
  print(f"\nCOUNTRY INFO \n\nCountry Name: {data['name']}\nRegion: {data['region']}\nSubregion: {data['subregion']}\n")
  print(f"latitude and longitude: {data['latlng']} \nArea: {data['area']}\nPopulation: {data['population']}\n")
  print(f"Currency: {data['currency']} \nTime Zone: {data['timezones']} \nLanguage: {data['language']}\n")
  print(f"Bordering Countries: {data['borders']} \nAlterntive spelling: {data['altSpellings']} \nStart of the week: {data['startOfWeek']} \n")
  