# Teammates: Ali, Mher
#--- Library ---#
import country_info

#--- Description ---#
print("In this program you will be picking a couple of options and then it gives you details about a country \n")

#--- Main Loop ---#
loop = True
while loop:
  option = input("Which option do you want? (search by (m)oney, search by (n)ame, search by (c)apital, search by (l)anguage, (q)uit)\n")

  #--- Search by NAME ---#
  if option.lower() == "n":
    while True:
      name = input("What is the name of the country?\n")
      print(country_info.countryInfo_byName(name))


      #--- Search another ---#
      again = input("Do you want to pick another? (y for yes and n for no)\n")
      if again.lower() == "n":
        print("\nOk no problem\n")
        break
        
      else:
        print("\nYour picking again")
  
  #--- Search by CAPITAL ---#    
  if option.lower() == "c":
    while True:
      capital = input("What is the name of the captial?\n") 
      print(country_info.countryInfo_byCapital(capital))

      #--- Search another ---#
      again = input("Do you want to pick another? (y for yes and n for no)\n")

      if again.lower() == "n":
        print("\nOk no problem\n")
        break
        
      else:
        print("\nYour picking again")

  #--- Search by MONEY (CURRENCY) ---#
  if option.lower() == "m":
    while True:
      money = input("What is the name of the currency?\n") 
      print(country_info.countryInfo_byCurrency(money))

      #--- Search another ---#
      again = input("Do you want to pick another? (y for yes and n for no)\n")
      if again.lower() == "n":
        print("\nOk no problem\n")
        break
        
      else:
        print("\nYour picking again")    

  #--- Search by LANGUAGE ---#
  if option.lower() == "l":
    while True:
      language = input("What is the name of the language?\n") 
      print(country_info.countryInfo_byLanguage(language))

      #--- Search another ---#
      again = input("Do you want to pick another? (y for yes and n for no)\n")
      if again.lower() == "y":
        print()
      if again.lower() == "n":
        print("\nOk no problem\n")
        break
        
      else:
        print("\nYour picking again")
  
  #--- QUIT ---#
  if option.lower() == "q":
    print("\nOk then, have a good day!\n")
    loop = False